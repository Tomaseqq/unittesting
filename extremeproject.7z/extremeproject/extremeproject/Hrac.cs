﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extremeproject
{
    class Hrac : HerniPostava
    {
        private string specializace;
        public string Specializace
        {
            get { return this.specializace; }
            set
            {
                string[] specs = { "Kouzelník", "Berserker", "Inženýr", "Cizák" };
                if (specs.Contains(value)) this.specializace = value;
            }
        }
        public enum obliceje {velkynos, Uchoplesk, makeup}
        private obliceje oblicej = 0;
        public enum sezvlasu { drdol, culik, pleska}
        private sezvlasu vlasy = 0;
        public enum barvyvlasu { kastanova, blond, cervena}
        private barvyvlasu barvavlasu = 0;
        public int XP = 0;
        public Hrac(string jmeno, string specializace, obliceje oblicej, sezvlasu vlasy, barvyvlasu barvyvlasu)        
            : base(jmeno)
        {
            this.Specializace = specializace;
            this.oblicej = oblicej;
            this.vlasy = vlasy;
            this.barvavlasu = barvyvlasu;
        }
        public void pridejXP (int XP)
        {
            this.XP = XP;
            if(XP % 100 > base.lvl)
            {
                base.lvl = XP / 100;
            }
        }
        public override string ToString()
        {
            string s = base.Jmeno + ", " + base.lvl + ", " + base.PoziceX + ", " + base.PoziceY + ", " + this.Specializace + ", " + this.oblicej + ", " +
                this.vlasy + ", " + this.barvavlasu;
            return s;
        }
    }
}
