﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace extremeproject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Hrac bonek = new Hrac("bonek", "Kouzelník", Hrac.obliceje.Uchoplesk, Hrac.sezvlasu.drdol, Hrac.barvyvlasu.blond);
            MessageBox.Show(bonek.ToString());
            NPC roger = new NPC("roger", NPC.sezprace.obyvatel, "NE");
            MessageBox.Show(roger.ToString());
        }
    }
}
