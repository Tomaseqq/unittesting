﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extremeproject
{
    class NPC : HerniPostava
    {
        public enum sezprace {obchodnik, nepritel, obyvatel}
        public sezprace prace;
        public string sila;
        public NPC(string jmeno, sezprace prace, string sila)
            : base(jmeno)
        {
            this.prace = prace;
            this.sila = sila;
        }
        public static void
    }
}
