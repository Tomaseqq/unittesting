﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace extremeproject
{
    class HerniPostava
    {
        public string Jmeno { get; set; }
        public int lvl = 1;
        private double poziceX = 0;
        private double poziceY = 0;
        public double PoziceX { get { return this.poziceX; } }
        public double PoziceY { get { return this.poziceY; } }
        public HerniPostava(string jmeno)
        {
            this.Jmeno = jmeno;
        }
        public void Zmenapozice(double x, double y)
        {
            this.poziceX = x;
            this.poziceY = y;
        }
        public override string ToString()
        {
            string s = this.Jmeno + ", " + this.lvl + ", " + this.PoziceX + ", " + this.PoziceY;
            return s;
        }

    }
}
